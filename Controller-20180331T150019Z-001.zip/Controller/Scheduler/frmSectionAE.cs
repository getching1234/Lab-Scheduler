﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.OleDb;
using System.Text;
using System.Windows.Forms;

namespace Scheduler
{
    public partial class frmSectionAE : Form
    {
        

        public frmSectionAE()
        {
            InitializeComponent();
        }

       

        private void frmSectionAE_Load(object sender, EventArgs e)
        {
           
        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
