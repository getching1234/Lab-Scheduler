﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Scheduler
{
    public partial class RoomSchedule : Form
    {
        public RoomSchedule()
        {
            InitializeComponent();
        }

        private void RoomSchedule_Load(object sender, EventArgs e)
        {

        }
    }
}
