﻿namespace Scheduler
{
    partial class frmFacultyAE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFacultyAE));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.cbxActiveService = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cboGender = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbxDepartment = new System.Windows.Forms.CheckedListBox();
            this.imgPicture = new System.Windows.Forms.PictureBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFacultyID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lsvClasslist = new System.Windows.Forms.ListView();
            this._column_80 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_81 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_82 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_83 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_84 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_85 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_86 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sbrLoad = new System.Windows.Forms.StatusBar();
            this._panel_76 = new System.Windows.Forms.StatusBarPanel();
            this._panel_77 = new System.Windows.Forms.StatusBarPanel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lsvLoad = new System.Windows.Forms.ListView();
            this._column_72 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_73 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_74 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_75 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.printClassListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lsvRoomSchedule = new System.Windows.Forms.ListView();
            this._column_78 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._column_79 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.cboSchoolYear = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgPicture)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._panel_76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._panel_77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btnBrowse);
            this.groupBox1.Controls.Add(this.cbxActiveService);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cboGender);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lbxDepartment);
            this.groupBox1.Controls.Add(this.imgPicture);
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.txtContact);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.txtMName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtFName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtLName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtFacultyID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(514, 429);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(408, 398);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 25);
            this.button2.TabIndex = 20;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(314, 399);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 25);
            this.button1.TabIndex = 19;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowse.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Image = ((System.Drawing.Image)(resources.GetObject("btnBrowse.Image")));
            this.btnBrowse.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBrowse.Location = new System.Drawing.Point(450, 157);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(54, 37);
            this.btnBrowse.TabIndex = 18;
            this.btnBrowse.Text = "&Browse";
            this.btnBrowse.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBrowse.UseVisualStyleBackColor = true;
            // 
            // cbxActiveService
            // 
            this.cbxActiveService.AutoSize = true;
            this.cbxActiveService.Location = new System.Drawing.Point(6, 400);
            this.cbxActiveService.Name = "cbxActiveService";
            this.cbxActiveService.Size = new System.Drawing.Size(98, 19);
            this.cbxActiveService.TabIndex = 17;
            this.cbxActiveService.Text = "Active service";
            this.cbxActiveService.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(13, 140);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Gender:";
            // 
            // cboGender
            // 
            this.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGender.ItemHeight = 15;
            this.cboGender.Items.AddRange(new object[] {
            "Female",
            "Male"});
            this.cboGender.Location = new System.Drawing.Point(16, 161);
            this.cboGender.Name = "cboGender";
            this.cboGender.Size = new System.Drawing.Size(97, 23);
            this.cboGender.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(15, 282);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Assigned department:";
            // 
            // lbxDepartment
            // 
            this.lbxDepartment.Location = new System.Drawing.Point(6, 326);
            this.lbxDepartment.Name = "lbxDepartment";
            this.lbxDepartment.Size = new System.Drawing.Size(107, 68);
            this.lbxDepartment.TabIndex = 12;
            this.lbxDepartment.SelectedIndexChanged += new System.EventHandler(this.lbxDepartment_SelectedIndexChanged);
            // 
            // imgPicture
            // 
            this.imgPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgPicture.Location = new System.Drawing.Point(372, 15);
            this.imgPicture.Name = "imgPicture";
            this.imgPicture.Size = new System.Drawing.Size(134, 135);
            this.imgPicture.TabIndex = 9;
            this.imgPicture.TabStop = false;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClear.Location = new System.Drawing.Point(448, 200);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(56, 27);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(192, 117);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(162, 21);
            this.txtContact.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(189, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Contact Info:";
            // 
            // txtAddress
            // 
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress.Location = new System.Drawing.Point(192, 44);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(162, 21);
            this.txtAddress.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(189, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Address:";
            // 
            // txtMName
            // 
            this.txtMName.Location = new System.Drawing.Point(16, 117);
            this.txtMName.Name = "txtMName";
            this.txtMName.Size = new System.Drawing.Size(162, 21);
            this.txtMName.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Middlename:";
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(16, 80);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(162, 21);
            this.txtFName.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Firstname:";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(16, 44);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(162, 21);
            this.txtLName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Lastname:";
            // 
            // txtFacultyID
            // 
            this.txtFacultyID.BackColor = System.Drawing.SystemColors.Info;
            this.txtFacultyID.Location = new System.Drawing.Point(16, 218);
            this.txtFacultyID.Name = "txtFacultyID";
            this.txtFacultyID.Size = new System.Drawing.Size(61, 21);
            this.txtFacultyID.TabIndex = 1;
            this.txtFacultyID.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Faculty ID:";
            this.label1.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(528, 461);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(520, 435);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Personal Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lsvClasslist);
            this.tabPage3.Controls.Add(this.sbrLoad);
            this.tabPage3.Controls.Add(this.splitContainer1);
            this.tabPage3.Controls.Add(this.toolStrip1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(506, 411);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Teaching Load";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lsvClasslist
            // 
            this.lsvClasslist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this._column_80,
            this._column_81,
            this._column_82,
            this._column_83,
            this._column_84,
            this._column_85,
            this._column_86});
            this.lsvClasslist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvClasslist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lsvClasslist.FullRowSelect = true;
            this.lsvClasslist.HideSelection = false;
            this.lsvClasslist.Location = new System.Drawing.Point(3, 139);
            this.lsvClasslist.Name = "lsvClasslist";
            this.lsvClasslist.Size = new System.Drawing.Size(500, 253);
            this.lsvClasslist.TabIndex = 8;
            this.lsvClasslist.UseCompatibleStateImageBehavior = false;
            this.lsvClasslist.View = System.Windows.Forms.View.Details;
            // 
            // _column_80
            // 
            this._column_80.Name = "_column_80";
            this._column_80.Text = "Student Name";
            this._column_80.Width = 163;
            // 
            // _column_81
            // 
            this._column_81.Name = "_column_81";
            this._column_81.Text = "Final Grade";
            this._column_81.Width = 85;
            // 
            // _column_82
            // 
            this._column_82.Name = "_column_82";
            this._column_82.Text = "Comp Grade";
            this._column_82.Width = 96;
            // 
            // _column_83
            // 
            this._column_83.Name = "_column_83";
            this._column_83.Text = "Submitted by";
            this._column_83.Width = 136;
            // 
            // _column_84
            // 
            this._column_84.Name = "_column_84";
            this._column_84.Text = "Date Submitted";
            this._column_84.Width = 122;
            // 
            // _column_85
            // 
            this._column_85.Name = "_column_85";
            this._column_85.Text = "Incomplete Remarks";
            this._column_85.Width = 135;
            // 
            // _column_86
            // 
            this._column_86.Name = "_column_86";
            this._column_86.Text = "Date Validated";
            this._column_86.Width = 110;
            // 
            // sbrLoad
            // 
            this.sbrLoad.Location = new System.Drawing.Point(3, 392);
            this.sbrLoad.Name = "sbrLoad";
            this.sbrLoad.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this._panel_76,
            this._panel_77});
            this.sbrLoad.ShowPanels = true;
            this.sbrLoad.Size = new System.Drawing.Size(500, 16);
            this.sbrLoad.TabIndex = 7;
            // 
            // _panel_76
            // 
            this._panel_76.Name = "_panel_76";
            // 
            // _panel_77
            // 
            this._panel_77.Name = "_panel_77";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lsvLoad);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lsvRoomSchedule);
            this.splitContainer1.Size = new System.Drawing.Size(500, 136);
            this.splitContainer1.SplitterDistance = 254;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 6;
            // 
            // lsvLoad
            // 
            this.lsvLoad.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this._column_72,
            this._column_73,
            this._column_74,
            this._column_75});
            this.lsvLoad.ContextMenuStrip = this.contextMenuStrip1;
            this.lsvLoad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvLoad.FullRowSelect = true;
            this.lsvLoad.HideSelection = false;
            this.lsvLoad.Location = new System.Drawing.Point(0, 0);
            this.lsvLoad.Name = "lsvLoad";
            this.lsvLoad.Size = new System.Drawing.Size(254, 136);
            this.lsvLoad.TabIndex = 3;
            this.lsvLoad.UseCompatibleStateImageBehavior = false;
            this.lsvLoad.View = System.Windows.Forms.View.Details;
            // 
            // _column_72
            // 
            this._column_72.Name = "_column_72";
            this._column_72.Text = "Subject";
            this._column_72.Width = 92;
            // 
            // _column_73
            // 
            this._column_73.Name = "_column_73";
            this._column_73.Text = "Section";
            this._column_73.Width = 86;
            // 
            // _column_74
            // 
            this._column_74.Name = "_column_74";
            this._column_74.Text = "Units";
            this._column_74.Width = 50;
            // 
            // _column_75
            // 
            this._column_75.Name = "_column_75";
            this._column_75.Text = "No Grade";
            this._column_75.Width = 84;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printClassListToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(151, 26);
            // 
            // printClassListToolStripMenuItem
            // 
            this.printClassListToolStripMenuItem.Name = "printClassListToolStripMenuItem";
            this.printClassListToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.printClassListToolStripMenuItem.Text = "Print class list...";
            // 
            // lsvRoomSchedule
            // 
            this.lsvRoomSchedule.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this._column_78,
            this._column_79});
            this.lsvRoomSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvRoomSchedule.FullRowSelect = true;
            this.lsvRoomSchedule.HideSelection = false;
            this.lsvRoomSchedule.Location = new System.Drawing.Point(0, 0);
            this.lsvRoomSchedule.Name = "lsvRoomSchedule";
            this.lsvRoomSchedule.Size = new System.Drawing.Size(243, 136);
            this.lsvRoomSchedule.TabIndex = 4;
            this.lsvRoomSchedule.UseCompatibleStateImageBehavior = false;
            this.lsvRoomSchedule.View = System.Windows.Forms.View.Details;
            // 
            // _column_78
            // 
            this._column_78.Name = "_column_78";
            this._column_78.Text = "Room Assignment";
            this._column_78.Width = 126;
            // 
            // _column_79
            // 
            this._column_79.Name = "_column_79";
            this._column_79.Text = "Class Schedule";
            this._column_79.Width = 166;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.cboSchoolYear,
            this.toolStripSeparator2,
            this.printToolStripButton,
            this.toolStripSeparator});
            this.toolStrip1.Location = new System.Drawing.Point(3, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(536, 22);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.Visible = false;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 22);
            // 
            // cboSchoolYear
            // 
            this.cboSchoolYear.Name = "cboSchoolYear";
            this.cboSchoolYear.Size = new System.Drawing.Size(121, 22);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 22);
            // 
            // printToolStripButton
            // 
            this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
            this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripButton.Name = "printToolStripButton";
            this.printToolStripButton.Size = new System.Drawing.Size(23, 19);
            this.printToolStripButton.Text = "&Print";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 22);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmFacultyAE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 461);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFacultyAE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Faculty";
            this.Load += new System.EventHandler(this.frmFacultyAE_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgPicture)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._panel_76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._panel_77)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFacultyID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.ListView lsvClasslist;
        public System.Windows.Forms.ColumnHeader _column_80;
        public System.Windows.Forms.ColumnHeader _column_81;
        public System.Windows.Forms.ColumnHeader _column_82;
        public System.Windows.Forms.ColumnHeader _column_83;
        public System.Windows.Forms.ColumnHeader _column_84;
        public System.Windows.Forms.ColumnHeader _column_85;
        public System.Windows.Forms.ColumnHeader _column_86;
        public System.Windows.Forms.StatusBar sbrLoad;
        public System.Windows.Forms.StatusBarPanel _panel_76;
        public System.Windows.Forms.StatusBarPanel _panel_77;
        private System.Windows.Forms.SplitContainer splitContainer1;
        public System.Windows.Forms.ListView lsvLoad;
        public System.Windows.Forms.ColumnHeader _column_72;
        public System.Windows.Forms.ColumnHeader _column_73;
        public System.Windows.Forms.ColumnHeader _column_74;
        public System.Windows.Forms.ColumnHeader _column_75;
        public System.Windows.Forms.ListView lsvRoomSchedule;
        public System.Windows.Forms.ColumnHeader _column_78;
        public System.Windows.Forms.ColumnHeader _column_79;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripComboBox cboSchoolYear;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem printClassListToolStripMenuItem;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.CheckedListBox lbxDepartment;
        public System.Windows.Forms.PictureBox imgPicture;
        public System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.ComboBox cboGender;
        private System.Windows.Forms.CheckBox cbxActiveService;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnBrowse;
    }
}