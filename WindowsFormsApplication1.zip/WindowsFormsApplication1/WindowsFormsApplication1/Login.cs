﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void SignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            Registration Registration = new Registration();
            Registration.Show();
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Gawdfree\Documents\RegistrationData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select Count (*) From Login where Username ='" + usertext.Text + "' and Password = '" + password.Text + "'", con);
            DataTable ss = new DataTable();
            sda.Fill(ss);

            if (ss.Rows[0][0].ToString() == "1")
            {

                this.Hide();
                Choice Choice = new Choice();
                Choice.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username/Password");
            }
        }

    }
}
