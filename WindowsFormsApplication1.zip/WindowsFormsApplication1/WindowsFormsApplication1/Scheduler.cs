﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Scheduler : Form
    {
        public Scheduler()
        {
            InitializeComponent();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Login Logout = new Login();
            Logout.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Prof.Text = "";
            subj.Text = "";
            YrSc.Text = "";
            RoomNo.Text = "";
            Time.Text = "";
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Choice back = new Choice();
            back.Show();
        }
    }
}
