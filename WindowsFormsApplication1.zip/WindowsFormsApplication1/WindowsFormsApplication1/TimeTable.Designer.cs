﻿namespace WindowsFormsApplication1
{
    partial class TimeTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TimeTable));
            this.Label18 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.sat10 = new System.Windows.Forms.Label();
            this.sat11 = new System.Windows.Forms.Label();
            this.sat2 = new System.Windows.Forms.Label();
            this.sat3 = new System.Windows.Forms.Label();
            this.sat4 = new System.Windows.Forms.Label();
            this.sat5 = new System.Windows.Forms.Label();
            this.sat6 = new System.Windows.Forms.Label();
            this.sat7 = new System.Windows.Forms.Label();
            this.sat8 = new System.Windows.Forms.Label();
            this.sat9 = new System.Windows.Forms.Label();
            this.sat1 = new System.Windows.Forms.Label();
            this.fri9 = new System.Windows.Forms.Label();
            this.fri10 = new System.Windows.Forms.Label();
            this.fri11 = new System.Windows.Forms.Label();
            this.fri2 = new System.Windows.Forms.Label();
            this.fri3 = new System.Windows.Forms.Label();
            this.fri4 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.fri5 = new System.Windows.Forms.Label();
            this.fri6 = new System.Windows.Forms.Label();
            this.fri7 = new System.Windows.Forms.Label();
            this.fri8 = new System.Windows.Forms.Label();
            this.fri1 = new System.Windows.Forms.Label();
            this.thurs11 = new System.Windows.Forms.Label();
            this.thurs2 = new System.Windows.Forms.Label();
            this.thurs3 = new System.Windows.Forms.Label();
            this.thurs4 = new System.Windows.Forms.Label();
            this.thurs9 = new System.Windows.Forms.Label();
            this.thurs8 = new System.Windows.Forms.Label();
            this.thurs7 = new System.Windows.Forms.Label();
            this.thurs6 = new System.Windows.Forms.Label();
            this.thurs10 = new System.Windows.Forms.Label();
            this.thurs5 = new System.Windows.Forms.Label();
            this.thurs1 = new System.Windows.Forms.Label();
            this.wed11 = new System.Windows.Forms.Label();
            this.wed8 = new System.Windows.Forms.Label();
            this.wed9 = new System.Windows.Forms.Label();
            this.wed10 = new System.Windows.Forms.Label();
            this.wed2 = new System.Windows.Forms.Label();
            this.wed3 = new System.Windows.Forms.Label();
            this.wed4 = new System.Windows.Forms.Label();
            this.wed7 = new System.Windows.Forms.Label();
            this.wed6 = new System.Windows.Forms.Label();
            this.wed5 = new System.Windows.Forms.Label();
            this.wed1 = new System.Windows.Forms.Label();
            this.tues10 = new System.Windows.Forms.Label();
            this.tues11 = new System.Windows.Forms.Label();
            this.tues2 = new System.Windows.Forms.Label();
            this.tues3 = new System.Windows.Forms.Label();
            this.tues4 = new System.Windows.Forms.Label();
            this.tues5 = new System.Windows.Forms.Label();
            this.tues6 = new System.Windows.Forms.Label();
            this.tues7 = new System.Windows.Forms.Label();
            this.tues8 = new System.Windows.Forms.Label();
            this.tues9 = new System.Windows.Forms.Label();
            this.tues1 = new System.Windows.Forms.Label();
            this.mon8 = new System.Windows.Forms.Label();
            this.mon9 = new System.Windows.Forms.Label();
            this.mon10 = new System.Windows.Forms.Label();
            this.mon11 = new System.Windows.Forms.Label();
            this.mon2 = new System.Windows.Forms.Label();
            this.mon3 = new System.Windows.Forms.Label();
            this.mon4 = new System.Windows.Forms.Label();
            this.mon5 = new System.Windows.Forms.Label();
            this.mon6 = new System.Windows.Forms.Label();
            this.mon7 = new System.Windows.Forms.Label();
            this.mon1 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.RmNumber = new System.Windows.Forms.TextBox();
            this.labnolabel = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.timetext = new System.Windows.Forms.TextBox();
            this.datepicker = new System.Windows.Forms.DateTimePicker();
            this.Search = new System.Windows.Forms.Button();
            this.Label19 = new System.Windows.Forms.Label();
            this.LinkLabel1 = new System.Windows.Forms.LinkLabel();
            this.Label21 = new System.Windows.Forms.Label();
            this.yrsectext = new System.Windows.Forms.TextBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label22 = new System.Windows.Forms.Label();
            this.datelabel = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label18
            // 
            this.Label18.BackColor = System.Drawing.Color.Transparent;
            this.Label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.Location = new System.Drawing.Point(16, 452);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(94, 41);
            this.Label18.TabIndex = 89;
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label17
            // 
            this.Label17.BackColor = System.Drawing.Color.Transparent;
            this.Label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.Location = new System.Drawing.Point(16, 83);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(94, 41);
            this.Label17.TabIndex = 88;
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label16
            // 
            this.Label16.BackColor = System.Drawing.Color.Transparent;
            this.Label16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(16, 124);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(94, 41);
            this.Label16.TabIndex = 87;
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label15
            // 
            this.Label15.BackColor = System.Drawing.Color.Transparent;
            this.Label15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.Location = new System.Drawing.Point(16, 165);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(94, 41);
            this.Label15.TabIndex = 86;
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label14
            // 
            this.Label14.BackColor = System.Drawing.Color.Transparent;
            this.Label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.Location = new System.Drawing.Point(16, 206);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(94, 41);
            this.Label14.TabIndex = 85;
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label13
            // 
            this.Label13.BackColor = System.Drawing.Color.Transparent;
            this.Label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(16, 249);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(94, 41);
            this.Label13.TabIndex = 84;
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label12
            // 
            this.Label12.BackColor = System.Drawing.Color.Transparent;
            this.Label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(16, 290);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(94, 41);
            this.Label12.TabIndex = 83;
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label11
            // 
            this.Label11.BackColor = System.Drawing.Color.Transparent;
            this.Label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(16, 331);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(94, 41);
            this.Label11.TabIndex = 82;
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label10
            // 
            this.Label10.BackColor = System.Drawing.Color.Transparent;
            this.Label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(16, 372);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(94, 41);
            this.Label10.TabIndex = 81;
            this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label9
            // 
            this.Label9.BackColor = System.Drawing.Color.Transparent;
            this.Label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(16, 413);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(94, 41);
            this.Label9.TabIndex = 80;
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label8
            // 
            this.Label8.BackColor = System.Drawing.Color.Transparent;
            this.Label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(16, 42);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(94, 41);
            this.Label8.TabIndex = 79;
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label7
            // 
            this.Label7.BackColor = System.Drawing.Color.DarkOrange;
            this.Label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(16, 19);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(94, 23);
            this.Label7.TabIndex = 78;
            this.Label7.Text = "Time";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat10
            // 
            this.sat10.BackColor = System.Drawing.Color.Transparent;
            this.sat10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat10.Location = new System.Drawing.Point(550, 411);
            this.sat10.Name = "sat10";
            this.sat10.Size = new System.Drawing.Size(85, 41);
            this.sat10.TabIndex = 77;
            this.sat10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat11
            // 
            this.sat11.BackColor = System.Drawing.Color.Transparent;
            this.sat11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat11.Location = new System.Drawing.Point(550, 452);
            this.sat11.Name = "sat11";
            this.sat11.Size = new System.Drawing.Size(85, 41);
            this.sat11.TabIndex = 76;
            this.sat11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat2
            // 
            this.sat2.BackColor = System.Drawing.Color.Transparent;
            this.sat2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat2.Location = new System.Drawing.Point(550, 83);
            this.sat2.Name = "sat2";
            this.sat2.Size = new System.Drawing.Size(85, 41);
            this.sat2.TabIndex = 75;
            this.sat2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat3
            // 
            this.sat3.BackColor = System.Drawing.Color.Transparent;
            this.sat3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat3.Location = new System.Drawing.Point(550, 124);
            this.sat3.Name = "sat3";
            this.sat3.Size = new System.Drawing.Size(85, 41);
            this.sat3.TabIndex = 74;
            this.sat3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat4
            // 
            this.sat4.BackColor = System.Drawing.Color.Transparent;
            this.sat4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat4.Location = new System.Drawing.Point(550, 165);
            this.sat4.Name = "sat4";
            this.sat4.Size = new System.Drawing.Size(85, 41);
            this.sat4.TabIndex = 73;
            this.sat4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat5
            // 
            this.sat5.BackColor = System.Drawing.Color.Transparent;
            this.sat5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat5.Location = new System.Drawing.Point(550, 206);
            this.sat5.Name = "sat5";
            this.sat5.Size = new System.Drawing.Size(85, 41);
            this.sat5.TabIndex = 72;
            this.sat5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat6
            // 
            this.sat6.BackColor = System.Drawing.Color.Transparent;
            this.sat6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat6.Location = new System.Drawing.Point(550, 247);
            this.sat6.Name = "sat6";
            this.sat6.Size = new System.Drawing.Size(85, 41);
            this.sat6.TabIndex = 71;
            this.sat6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat7
            // 
            this.sat7.BackColor = System.Drawing.Color.Transparent;
            this.sat7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat7.Location = new System.Drawing.Point(550, 288);
            this.sat7.Name = "sat7";
            this.sat7.Size = new System.Drawing.Size(85, 41);
            this.sat7.TabIndex = 70;
            this.sat7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat8
            // 
            this.sat8.BackColor = System.Drawing.Color.Transparent;
            this.sat8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat8.Location = new System.Drawing.Point(550, 329);
            this.sat8.Name = "sat8";
            this.sat8.Size = new System.Drawing.Size(85, 41);
            this.sat8.TabIndex = 69;
            this.sat8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat9
            // 
            this.sat9.BackColor = System.Drawing.Color.Transparent;
            this.sat9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat9.Location = new System.Drawing.Point(550, 370);
            this.sat9.Name = "sat9";
            this.sat9.Size = new System.Drawing.Size(85, 41);
            this.sat9.TabIndex = 68;
            this.sat9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sat1
            // 
            this.sat1.BackColor = System.Drawing.Color.Transparent;
            this.sat1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sat1.Location = new System.Drawing.Point(550, 42);
            this.sat1.Name = "sat1";
            this.sat1.Size = new System.Drawing.Size(85, 41);
            this.sat1.TabIndex = 67;
            this.sat1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri9
            // 
            this.fri9.BackColor = System.Drawing.Color.Transparent;
            this.fri9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri9.Location = new System.Drawing.Point(472, 370);
            this.fri9.Name = "fri9";
            this.fri9.Size = new System.Drawing.Size(77, 41);
            this.fri9.TabIndex = 66;
            this.fri9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri10
            // 
            this.fri10.BackColor = System.Drawing.Color.Transparent;
            this.fri10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri10.Location = new System.Drawing.Point(472, 411);
            this.fri10.Name = "fri10";
            this.fri10.Size = new System.Drawing.Size(77, 41);
            this.fri10.TabIndex = 65;
            this.fri10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri11
            // 
            this.fri11.BackColor = System.Drawing.Color.Transparent;
            this.fri11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri11.Location = new System.Drawing.Point(472, 452);
            this.fri11.Name = "fri11";
            this.fri11.Size = new System.Drawing.Size(77, 41);
            this.fri11.TabIndex = 64;
            this.fri11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri2
            // 
            this.fri2.BackColor = System.Drawing.Color.Transparent;
            this.fri2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri2.Location = new System.Drawing.Point(472, 83);
            this.fri2.Name = "fri2";
            this.fri2.Size = new System.Drawing.Size(77, 41);
            this.fri2.TabIndex = 63;
            this.fri2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri3
            // 
            this.fri3.BackColor = System.Drawing.Color.Transparent;
            this.fri3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri3.Location = new System.Drawing.Point(472, 124);
            this.fri3.Name = "fri3";
            this.fri3.Size = new System.Drawing.Size(77, 41);
            this.fri3.TabIndex = 62;
            this.fri3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri4
            // 
            this.fri4.BackColor = System.Drawing.Color.Transparent;
            this.fri4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri4.Location = new System.Drawing.Point(472, 165);
            this.fri4.Name = "fri4";
            this.fri4.Size = new System.Drawing.Size(77, 41);
            this.fri4.TabIndex = 61;
            this.fri4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Label18);
            this.Panel1.Controls.Add(this.Label17);
            this.Panel1.Controls.Add(this.Label16);
            this.Panel1.Controls.Add(this.Label15);
            this.Panel1.Controls.Add(this.Label14);
            this.Panel1.Controls.Add(this.Label13);
            this.Panel1.Controls.Add(this.Label12);
            this.Panel1.Controls.Add(this.Label11);
            this.Panel1.Controls.Add(this.Label10);
            this.Panel1.Controls.Add(this.Label9);
            this.Panel1.Controls.Add(this.Label8);
            this.Panel1.Controls.Add(this.Label7);
            this.Panel1.Controls.Add(this.sat10);
            this.Panel1.Controls.Add(this.sat11);
            this.Panel1.Controls.Add(this.sat2);
            this.Panel1.Controls.Add(this.sat3);
            this.Panel1.Controls.Add(this.sat4);
            this.Panel1.Controls.Add(this.sat5);
            this.Panel1.Controls.Add(this.sat6);
            this.Panel1.Controls.Add(this.sat7);
            this.Panel1.Controls.Add(this.sat8);
            this.Panel1.Controls.Add(this.sat9);
            this.Panel1.Controls.Add(this.sat1);
            this.Panel1.Controls.Add(this.fri9);
            this.Panel1.Controls.Add(this.fri10);
            this.Panel1.Controls.Add(this.fri11);
            this.Panel1.Controls.Add(this.fri2);
            this.Panel1.Controls.Add(this.fri3);
            this.Panel1.Controls.Add(this.fri4);
            this.Panel1.Controls.Add(this.fri5);
            this.Panel1.Controls.Add(this.fri6);
            this.Panel1.Controls.Add(this.fri7);
            this.Panel1.Controls.Add(this.fri8);
            this.Panel1.Controls.Add(this.fri1);
            this.Panel1.Controls.Add(this.thurs11);
            this.Panel1.Controls.Add(this.thurs2);
            this.Panel1.Controls.Add(this.thurs3);
            this.Panel1.Controls.Add(this.thurs4);
            this.Panel1.Controls.Add(this.thurs9);
            this.Panel1.Controls.Add(this.thurs8);
            this.Panel1.Controls.Add(this.thurs7);
            this.Panel1.Controls.Add(this.thurs6);
            this.Panel1.Controls.Add(this.thurs10);
            this.Panel1.Controls.Add(this.thurs5);
            this.Panel1.Controls.Add(this.thurs1);
            this.Panel1.Controls.Add(this.wed11);
            this.Panel1.Controls.Add(this.wed8);
            this.Panel1.Controls.Add(this.wed9);
            this.Panel1.Controls.Add(this.wed10);
            this.Panel1.Controls.Add(this.wed2);
            this.Panel1.Controls.Add(this.wed3);
            this.Panel1.Controls.Add(this.wed4);
            this.Panel1.Controls.Add(this.wed7);
            this.Panel1.Controls.Add(this.wed6);
            this.Panel1.Controls.Add(this.wed5);
            this.Panel1.Controls.Add(this.wed1);
            this.Panel1.Controls.Add(this.tues10);
            this.Panel1.Controls.Add(this.tues11);
            this.Panel1.Controls.Add(this.tues2);
            this.Panel1.Controls.Add(this.tues3);
            this.Panel1.Controls.Add(this.tues4);
            this.Panel1.Controls.Add(this.tues5);
            this.Panel1.Controls.Add(this.tues6);
            this.Panel1.Controls.Add(this.tues7);
            this.Panel1.Controls.Add(this.tues8);
            this.Panel1.Controls.Add(this.tues9);
            this.Panel1.Controls.Add(this.tues1);
            this.Panel1.Controls.Add(this.mon8);
            this.Panel1.Controls.Add(this.mon9);
            this.Panel1.Controls.Add(this.mon10);
            this.Panel1.Controls.Add(this.mon11);
            this.Panel1.Controls.Add(this.mon2);
            this.Panel1.Controls.Add(this.mon3);
            this.Panel1.Controls.Add(this.mon4);
            this.Panel1.Controls.Add(this.mon5);
            this.Panel1.Controls.Add(this.mon6);
            this.Panel1.Controls.Add(this.mon7);
            this.Panel1.Controls.Add(this.mon1);
            this.Panel1.Controls.Add(this.Label6);
            this.Panel1.Controls.Add(this.Label5);
            this.Panel1.Controls.Add(this.Label4);
            this.Panel1.Controls.Add(this.Label3);
            this.Panel1.Controls.Add(this.Label2);
            this.Panel1.Controls.Add(this.Label1);
            this.Panel1.Location = new System.Drawing.Point(140, 21);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(641, 507);
            this.Panel1.TabIndex = 117;
            // 
            // fri5
            // 
            this.fri5.BackColor = System.Drawing.Color.Transparent;
            this.fri5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri5.Location = new System.Drawing.Point(472, 206);
            this.fri5.Name = "fri5";
            this.fri5.Size = new System.Drawing.Size(77, 41);
            this.fri5.TabIndex = 60;
            this.fri5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri6
            // 
            this.fri6.BackColor = System.Drawing.Color.Transparent;
            this.fri6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri6.Location = new System.Drawing.Point(472, 247);
            this.fri6.Name = "fri6";
            this.fri6.Size = new System.Drawing.Size(77, 41);
            this.fri6.TabIndex = 59;
            this.fri6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri7
            // 
            this.fri7.BackColor = System.Drawing.Color.Transparent;
            this.fri7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri7.Location = new System.Drawing.Point(472, 288);
            this.fri7.Name = "fri7";
            this.fri7.Size = new System.Drawing.Size(77, 41);
            this.fri7.TabIndex = 58;
            this.fri7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri8
            // 
            this.fri8.BackColor = System.Drawing.Color.Transparent;
            this.fri8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri8.Location = new System.Drawing.Point(472, 329);
            this.fri8.Name = "fri8";
            this.fri8.Size = new System.Drawing.Size(77, 41);
            this.fri8.TabIndex = 57;
            this.fri8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fri1
            // 
            this.fri1.BackColor = System.Drawing.Color.Transparent;
            this.fri1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fri1.Location = new System.Drawing.Point(472, 42);
            this.fri1.Name = "fri1";
            this.fri1.Size = new System.Drawing.Size(77, 41);
            this.fri1.TabIndex = 56;
            this.fri1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs11
            // 
            this.thurs11.BackColor = System.Drawing.Color.Transparent;
            this.thurs11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs11.Location = new System.Drawing.Point(385, 452);
            this.thurs11.Name = "thurs11";
            this.thurs11.Size = new System.Drawing.Size(86, 41);
            this.thurs11.TabIndex = 49;
            this.thurs11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs2
            // 
            this.thurs2.BackColor = System.Drawing.Color.Transparent;
            this.thurs2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs2.Location = new System.Drawing.Point(385, 83);
            this.thurs2.Name = "thurs2";
            this.thurs2.Size = new System.Drawing.Size(86, 41);
            this.thurs2.TabIndex = 48;
            this.thurs2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs3
            // 
            this.thurs3.BackColor = System.Drawing.Color.Transparent;
            this.thurs3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs3.Location = new System.Drawing.Point(385, 124);
            this.thurs3.Name = "thurs3";
            this.thurs3.Size = new System.Drawing.Size(86, 41);
            this.thurs3.TabIndex = 47;
            this.thurs3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs4
            // 
            this.thurs4.BackColor = System.Drawing.Color.Transparent;
            this.thurs4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs4.Location = new System.Drawing.Point(385, 165);
            this.thurs4.Name = "thurs4";
            this.thurs4.Size = new System.Drawing.Size(86, 41);
            this.thurs4.TabIndex = 46;
            this.thurs4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs9
            // 
            this.thurs9.BackColor = System.Drawing.Color.Transparent;
            this.thurs9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs9.Location = new System.Drawing.Point(385, 370);
            this.thurs9.Name = "thurs9";
            this.thurs9.Size = new System.Drawing.Size(86, 41);
            this.thurs9.TabIndex = 45;
            this.thurs9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs8
            // 
            this.thurs8.BackColor = System.Drawing.Color.Transparent;
            this.thurs8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs8.Location = new System.Drawing.Point(385, 329);
            this.thurs8.Name = "thurs8";
            this.thurs8.Size = new System.Drawing.Size(86, 41);
            this.thurs8.TabIndex = 44;
            this.thurs8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs7
            // 
            this.thurs7.BackColor = System.Drawing.Color.Transparent;
            this.thurs7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs7.Location = new System.Drawing.Point(385, 288);
            this.thurs7.Name = "thurs7";
            this.thurs7.Size = new System.Drawing.Size(86, 41);
            this.thurs7.TabIndex = 43;
            this.thurs7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs6
            // 
            this.thurs6.BackColor = System.Drawing.Color.Transparent;
            this.thurs6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs6.Location = new System.Drawing.Point(385, 247);
            this.thurs6.Name = "thurs6";
            this.thurs6.Size = new System.Drawing.Size(86, 41);
            this.thurs6.TabIndex = 42;
            this.thurs6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs10
            // 
            this.thurs10.BackColor = System.Drawing.Color.Transparent;
            this.thurs10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs10.Location = new System.Drawing.Point(385, 411);
            this.thurs10.Name = "thurs10";
            this.thurs10.Size = new System.Drawing.Size(86, 41);
            this.thurs10.TabIndex = 41;
            this.thurs10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs5
            // 
            this.thurs5.BackColor = System.Drawing.Color.Transparent;
            this.thurs5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs5.Location = new System.Drawing.Point(385, 206);
            this.thurs5.Name = "thurs5";
            this.thurs5.Size = new System.Drawing.Size(86, 41);
            this.thurs5.TabIndex = 40;
            this.thurs5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thurs1
            // 
            this.thurs1.BackColor = System.Drawing.Color.Transparent;
            this.thurs1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thurs1.Location = new System.Drawing.Point(385, 42);
            this.thurs1.Name = "thurs1";
            this.thurs1.Size = new System.Drawing.Size(86, 41);
            this.thurs1.TabIndex = 39;
            this.thurs1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed11
            // 
            this.wed11.BackColor = System.Drawing.Color.Transparent;
            this.wed11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed11.Location = new System.Drawing.Point(282, 452);
            this.wed11.Name = "wed11";
            this.wed11.Size = new System.Drawing.Size(102, 41);
            this.wed11.TabIndex = 38;
            this.wed11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed8
            // 
            this.wed8.BackColor = System.Drawing.Color.Transparent;
            this.wed8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed8.Location = new System.Drawing.Point(282, 329);
            this.wed8.Name = "wed8";
            this.wed8.Size = new System.Drawing.Size(102, 41);
            this.wed8.TabIndex = 37;
            this.wed8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed9
            // 
            this.wed9.BackColor = System.Drawing.Color.Transparent;
            this.wed9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed9.Location = new System.Drawing.Point(282, 370);
            this.wed9.Name = "wed9";
            this.wed9.Size = new System.Drawing.Size(102, 41);
            this.wed9.TabIndex = 36;
            this.wed9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed10
            // 
            this.wed10.BackColor = System.Drawing.Color.Transparent;
            this.wed10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed10.Location = new System.Drawing.Point(282, 411);
            this.wed10.Name = "wed10";
            this.wed10.Size = new System.Drawing.Size(102, 41);
            this.wed10.TabIndex = 35;
            this.wed10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed2
            // 
            this.wed2.BackColor = System.Drawing.Color.Transparent;
            this.wed2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed2.Location = new System.Drawing.Point(282, 83);
            this.wed2.Name = "wed2";
            this.wed2.Size = new System.Drawing.Size(102, 41);
            this.wed2.TabIndex = 34;
            this.wed2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed3
            // 
            this.wed3.BackColor = System.Drawing.Color.Transparent;
            this.wed3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed3.Location = new System.Drawing.Point(282, 124);
            this.wed3.Name = "wed3";
            this.wed3.Size = new System.Drawing.Size(102, 41);
            this.wed3.TabIndex = 33;
            this.wed3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed4
            // 
            this.wed4.BackColor = System.Drawing.Color.Transparent;
            this.wed4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed4.Location = new System.Drawing.Point(282, 165);
            this.wed4.Name = "wed4";
            this.wed4.Size = new System.Drawing.Size(102, 41);
            this.wed4.TabIndex = 32;
            this.wed4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed7
            // 
            this.wed7.BackColor = System.Drawing.Color.Transparent;
            this.wed7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed7.Location = new System.Drawing.Point(282, 288);
            this.wed7.Name = "wed7";
            this.wed7.Size = new System.Drawing.Size(102, 41);
            this.wed7.TabIndex = 31;
            this.wed7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed6
            // 
            this.wed6.BackColor = System.Drawing.Color.Transparent;
            this.wed6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed6.Location = new System.Drawing.Point(282, 247);
            this.wed6.Name = "wed6";
            this.wed6.Size = new System.Drawing.Size(102, 41);
            this.wed6.TabIndex = 30;
            this.wed6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed5
            // 
            this.wed5.BackColor = System.Drawing.Color.Transparent;
            this.wed5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed5.Location = new System.Drawing.Point(282, 206);
            this.wed5.Name = "wed5";
            this.wed5.Size = new System.Drawing.Size(102, 41);
            this.wed5.TabIndex = 29;
            this.wed5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wed1
            // 
            this.wed1.BackColor = System.Drawing.Color.Transparent;
            this.wed1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wed1.Location = new System.Drawing.Point(282, 42);
            this.wed1.Name = "wed1";
            this.wed1.Size = new System.Drawing.Size(102, 41);
            this.wed1.TabIndex = 28;
            this.wed1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues10
            // 
            this.tues10.BackColor = System.Drawing.Color.Transparent;
            this.tues10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues10.Location = new System.Drawing.Point(203, 411);
            this.tues10.Name = "tues10";
            this.tues10.Size = new System.Drawing.Size(78, 41);
            this.tues10.TabIndex = 27;
            this.tues10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues11
            // 
            this.tues11.BackColor = System.Drawing.Color.Transparent;
            this.tues11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues11.Location = new System.Drawing.Point(203, 452);
            this.tues11.Name = "tues11";
            this.tues11.Size = new System.Drawing.Size(78, 41);
            this.tues11.TabIndex = 26;
            this.tues11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues2
            // 
            this.tues2.BackColor = System.Drawing.Color.Transparent;
            this.tues2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues2.Location = new System.Drawing.Point(203, 83);
            this.tues2.Name = "tues2";
            this.tues2.Size = new System.Drawing.Size(78, 41);
            this.tues2.TabIndex = 25;
            this.tues2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues3
            // 
            this.tues3.BackColor = System.Drawing.Color.Transparent;
            this.tues3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues3.Location = new System.Drawing.Point(203, 124);
            this.tues3.Name = "tues3";
            this.tues3.Size = new System.Drawing.Size(78, 41);
            this.tues3.TabIndex = 24;
            this.tues3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues4
            // 
            this.tues4.BackColor = System.Drawing.Color.Transparent;
            this.tues4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues4.Location = new System.Drawing.Point(203, 165);
            this.tues4.Name = "tues4";
            this.tues4.Size = new System.Drawing.Size(78, 41);
            this.tues4.TabIndex = 23;
            this.tues4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues5
            // 
            this.tues5.BackColor = System.Drawing.Color.Transparent;
            this.tues5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues5.Location = new System.Drawing.Point(203, 206);
            this.tues5.Name = "tues5";
            this.tues5.Size = new System.Drawing.Size(78, 41);
            this.tues5.TabIndex = 22;
            this.tues5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues6
            // 
            this.tues6.BackColor = System.Drawing.Color.Transparent;
            this.tues6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues6.Location = new System.Drawing.Point(203, 247);
            this.tues6.Name = "tues6";
            this.tues6.Size = new System.Drawing.Size(78, 41);
            this.tues6.TabIndex = 21;
            this.tues6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues7
            // 
            this.tues7.BackColor = System.Drawing.Color.Transparent;
            this.tues7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues7.Location = new System.Drawing.Point(203, 288);
            this.tues7.Name = "tues7";
            this.tues7.Size = new System.Drawing.Size(78, 41);
            this.tues7.TabIndex = 20;
            this.tues7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues8
            // 
            this.tues8.BackColor = System.Drawing.Color.Transparent;
            this.tues8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues8.Location = new System.Drawing.Point(203, 329);
            this.tues8.Name = "tues8";
            this.tues8.Size = new System.Drawing.Size(78, 41);
            this.tues8.TabIndex = 19;
            this.tues8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues9
            // 
            this.tues9.BackColor = System.Drawing.Color.Transparent;
            this.tues9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues9.Location = new System.Drawing.Point(203, 370);
            this.tues9.Name = "tues9";
            this.tues9.Size = new System.Drawing.Size(78, 41);
            this.tues9.TabIndex = 18;
            this.tues9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tues1
            // 
            this.tues1.BackColor = System.Drawing.Color.Transparent;
            this.tues1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tues1.Location = new System.Drawing.Point(203, 42);
            this.tues1.Name = "tues1";
            this.tues1.Size = new System.Drawing.Size(78, 41);
            this.tues1.TabIndex = 17;
            this.tues1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon8
            // 
            this.mon8.BackColor = System.Drawing.Color.Transparent;
            this.mon8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon8.Location = new System.Drawing.Point(122, 329);
            this.mon8.Name = "mon8";
            this.mon8.Size = new System.Drawing.Size(80, 41);
            this.mon8.TabIndex = 16;
            this.mon8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon9
            // 
            this.mon9.BackColor = System.Drawing.Color.Transparent;
            this.mon9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon9.Location = new System.Drawing.Point(122, 370);
            this.mon9.Name = "mon9";
            this.mon9.Size = new System.Drawing.Size(80, 41);
            this.mon9.TabIndex = 15;
            this.mon9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon10
            // 
            this.mon10.BackColor = System.Drawing.Color.Transparent;
            this.mon10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon10.Location = new System.Drawing.Point(122, 411);
            this.mon10.Name = "mon10";
            this.mon10.Size = new System.Drawing.Size(80, 41);
            this.mon10.TabIndex = 14;
            this.mon10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon11
            // 
            this.mon11.BackColor = System.Drawing.Color.Transparent;
            this.mon11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon11.Location = new System.Drawing.Point(122, 452);
            this.mon11.Name = "mon11";
            this.mon11.Size = new System.Drawing.Size(80, 41);
            this.mon11.TabIndex = 13;
            this.mon11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon2
            // 
            this.mon2.BackColor = System.Drawing.Color.Transparent;
            this.mon2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon2.Location = new System.Drawing.Point(122, 83);
            this.mon2.Name = "mon2";
            this.mon2.Size = new System.Drawing.Size(80, 41);
            this.mon2.TabIndex = 12;
            this.mon2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon3
            // 
            this.mon3.BackColor = System.Drawing.Color.Transparent;
            this.mon3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon3.Location = new System.Drawing.Point(122, 124);
            this.mon3.Name = "mon3";
            this.mon3.Size = new System.Drawing.Size(80, 41);
            this.mon3.TabIndex = 11;
            this.mon3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon4
            // 
            this.mon4.BackColor = System.Drawing.Color.Transparent;
            this.mon4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon4.Location = new System.Drawing.Point(122, 165);
            this.mon4.Name = "mon4";
            this.mon4.Size = new System.Drawing.Size(80, 41);
            this.mon4.TabIndex = 10;
            this.mon4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon5
            // 
            this.mon5.BackColor = System.Drawing.Color.Transparent;
            this.mon5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon5.Location = new System.Drawing.Point(122, 206);
            this.mon5.Name = "mon5";
            this.mon5.Size = new System.Drawing.Size(80, 41);
            this.mon5.TabIndex = 9;
            this.mon5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon6
            // 
            this.mon6.BackColor = System.Drawing.Color.Transparent;
            this.mon6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon6.Location = new System.Drawing.Point(122, 247);
            this.mon6.Name = "mon6";
            this.mon6.Size = new System.Drawing.Size(80, 41);
            this.mon6.TabIndex = 8;
            this.mon6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon7
            // 
            this.mon7.BackColor = System.Drawing.Color.Transparent;
            this.mon7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon7.Location = new System.Drawing.Point(122, 288);
            this.mon7.Name = "mon7";
            this.mon7.Size = new System.Drawing.Size(80, 41);
            this.mon7.TabIndex = 7;
            this.mon7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mon1
            // 
            this.mon1.BackColor = System.Drawing.Color.Transparent;
            this.mon1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon1.Location = new System.Drawing.Point(122, 42);
            this.mon1.Name = "mon1";
            this.mon1.Size = new System.Drawing.Size(80, 41);
            this.mon1.TabIndex = 6;
            this.mon1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label6
            // 
            this.Label6.BackColor = System.Drawing.Color.DarkOrange;
            this.Label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(550, 19);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(85, 23);
            this.Label6.TabIndex = 5;
            this.Label6.Text = "Saturday";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label5
            // 
            this.Label5.BackColor = System.Drawing.Color.DarkOrange;
            this.Label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(203, 19);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(78, 23);
            this.Label5.TabIndex = 4;
            this.Label5.Text = "Tuesday";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label4
            // 
            this.Label4.BackColor = System.Drawing.Color.DarkOrange;
            this.Label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(282, 19);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(102, 23);
            this.Label4.TabIndex = 3;
            this.Label4.Text = "Wednesday";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.Color.DarkOrange;
            this.Label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(385, 19);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(86, 23);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Thursday";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.DarkOrange;
            this.Label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(472, 19);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(77, 23);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Friday";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label1
            // 
            this.Label1.BackColor = System.Drawing.Color.DarkOrange;
            this.Label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(122, 19);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(80, 23);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Monday";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RmNumber
            // 
            this.RmNumber.Location = new System.Drawing.Point(26, 166);
            this.RmNumber.Name = "RmNumber";
            this.RmNumber.Size = new System.Drawing.Size(91, 20);
            this.RmNumber.TabIndex = 130;
            // 
            // labnolabel
            // 
            this.labnolabel.BackColor = System.Drawing.Color.Transparent;
            this.labnolabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labnolabel.Location = new System.Drawing.Point(23, 106);
            this.labnolabel.Name = "labnolabel";
            this.labnolabel.Size = new System.Drawing.Size(94, 41);
            this.labnolabel.TabIndex = 118;
            this.labnolabel.Text = "CpE Room No.:";
            this.labnolabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label24
            // 
            this.Label24.BackColor = System.Drawing.Color.Transparent;
            this.Label24.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.Location = new System.Drawing.Point(26, 392);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(91, 21);
            this.Label24.TabIndex = 125;
            this.Label24.Text = "Time:";
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timetext
            // 
            this.timetext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timetext.Location = new System.Drawing.Point(26, 416);
            this.timetext.Multiline = true;
            this.timetext.Name = "timetext";
            this.timetext.Size = new System.Drawing.Size(91, 23);
            this.timetext.TabIndex = 126;
            // 
            // datepicker
            // 
            this.datepicker.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datepicker.Location = new System.Drawing.Point(26, 291);
            this.datepicker.Name = "datepicker";
            this.datepicker.Size = new System.Drawing.Size(91, 20);
            this.datepicker.TabIndex = 123;
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.Color.Transparent;
            this.Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.Location = new System.Drawing.Point(26, 457);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(91, 44);
            this.Search.TabIndex = 127;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = false;
            // 
            // Label19
            // 
            this.Label19.BackColor = System.Drawing.Color.Transparent;
            this.Label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.Location = new System.Drawing.Point(26, 176);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(91, 42);
            this.Label19.TabIndex = 129;
            this.Label19.Text = "---------------------";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LinkLabel1
            // 
            this.LinkLabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinkLabel1.Location = new System.Drawing.Point(4, 9);
            this.LinkLabel1.Name = "LinkLabel1";
            this.LinkLabel1.Size = new System.Drawing.Size(91, 19);
            this.LinkLabel1.TabIndex = 128;
            this.LinkLabel1.TabStop = true;
            this.LinkLabel1.Text = "<-- Back";
            this.LinkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel1_LinkClicked);
            // 
            // Label21
            // 
            this.Label21.BackColor = System.Drawing.Color.Transparent;
            this.Label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(23, 214);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(94, 42);
            this.Label21.TabIndex = 121;
            this.Label21.Text = "Schedule Finder";
            this.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // yrsectext
            // 
            this.yrsectext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yrsectext.Location = new System.Drawing.Point(26, 352);
            this.yrsectext.Multiline = true;
            this.yrsectext.Name = "yrsectext";
            this.yrsectext.Size = new System.Drawing.Size(91, 23);
            this.yrsectext.TabIndex = 120;
            // 
            // Label23
            // 
            this.Label23.BackColor = System.Drawing.Color.Transparent;
            this.Label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label23.Location = new System.Drawing.Point(26, 328);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(91, 21);
            this.Label23.TabIndex = 124;
            this.Label23.Text = "Year/Section:";
            this.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label22
            // 
            this.Label22.BackColor = System.Drawing.Color.Transparent;
            this.Label22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label22.Location = new System.Drawing.Point(26, 267);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(91, 21);
            this.Label22.TabIndex = 122;
            this.Label22.Text = "Date:";
            this.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datelabel
            // 
            this.datelabel.BackColor = System.Drawing.Color.Transparent;
            this.datelabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelabel.Location = new System.Drawing.Point(23, 30);
            this.datelabel.Name = "datelabel";
            this.datelabel.Size = new System.Drawing.Size(94, 42);
            this.datelabel.TabIndex = 119;
            this.datelabel.Text = "Date:";
            this.datelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TimeTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(812, 544);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.RmNumber);
            this.Controls.Add(this.labnolabel);
            this.Controls.Add(this.Label24);
            this.Controls.Add(this.timetext);
            this.Controls.Add(this.datepicker);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.LinkLabel1);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.yrsectext);
            this.Controls.Add(this.Label23);
            this.Controls.Add(this.Label22);
            this.Controls.Add(this.datelabel);
            this.DoubleBuffered = true;
            this.Name = "TimeTable";
            this.Text = "TimeTable";
            this.Panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label sat10;
        internal System.Windows.Forms.Label sat11;
        internal System.Windows.Forms.Label sat2;
        internal System.Windows.Forms.Label sat3;
        internal System.Windows.Forms.Label sat4;
        internal System.Windows.Forms.Label sat5;
        internal System.Windows.Forms.Label sat6;
        internal System.Windows.Forms.Label sat7;
        internal System.Windows.Forms.Label sat8;
        internal System.Windows.Forms.Label sat9;
        internal System.Windows.Forms.Label sat1;
        internal System.Windows.Forms.Label fri9;
        internal System.Windows.Forms.Label fri10;
        internal System.Windows.Forms.Label fri11;
        internal System.Windows.Forms.Label fri2;
        internal System.Windows.Forms.Label fri3;
        internal System.Windows.Forms.Label fri4;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label fri5;
        internal System.Windows.Forms.Label fri6;
        internal System.Windows.Forms.Label fri7;
        internal System.Windows.Forms.Label fri8;
        internal System.Windows.Forms.Label fri1;
        internal System.Windows.Forms.Label thurs11;
        internal System.Windows.Forms.Label thurs2;
        internal System.Windows.Forms.Label thurs3;
        internal System.Windows.Forms.Label thurs4;
        internal System.Windows.Forms.Label thurs9;
        internal System.Windows.Forms.Label thurs8;
        internal System.Windows.Forms.Label thurs7;
        internal System.Windows.Forms.Label thurs6;
        internal System.Windows.Forms.Label thurs10;
        internal System.Windows.Forms.Label thurs5;
        internal System.Windows.Forms.Label thurs1;
        internal System.Windows.Forms.Label wed11;
        internal System.Windows.Forms.Label wed8;
        internal System.Windows.Forms.Label wed9;
        internal System.Windows.Forms.Label wed10;
        internal System.Windows.Forms.Label wed2;
        internal System.Windows.Forms.Label wed3;
        internal System.Windows.Forms.Label wed4;
        internal System.Windows.Forms.Label wed7;
        internal System.Windows.Forms.Label wed6;
        internal System.Windows.Forms.Label wed5;
        internal System.Windows.Forms.Label wed1;
        internal System.Windows.Forms.Label tues10;
        internal System.Windows.Forms.Label tues11;
        internal System.Windows.Forms.Label tues2;
        internal System.Windows.Forms.Label tues3;
        internal System.Windows.Forms.Label tues4;
        internal System.Windows.Forms.Label tues5;
        internal System.Windows.Forms.Label tues6;
        internal System.Windows.Forms.Label tues7;
        internal System.Windows.Forms.Label tues8;
        internal System.Windows.Forms.Label tues9;
        internal System.Windows.Forms.Label tues1;
        internal System.Windows.Forms.Label mon8;
        internal System.Windows.Forms.Label mon9;
        internal System.Windows.Forms.Label mon10;
        internal System.Windows.Forms.Label mon11;
        internal System.Windows.Forms.Label mon2;
        internal System.Windows.Forms.Label mon3;
        internal System.Windows.Forms.Label mon4;
        internal System.Windows.Forms.Label mon5;
        internal System.Windows.Forms.Label mon6;
        internal System.Windows.Forms.Label mon7;
        internal System.Windows.Forms.Label mon1;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox RmNumber;
        internal System.Windows.Forms.Label labnolabel;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.TextBox timetext;
        internal System.Windows.Forms.DateTimePicker datepicker;
        internal System.Windows.Forms.Button Search;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.LinkLabel LinkLabel1;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.TextBox yrsectext;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.Label datelabel;
    }
}