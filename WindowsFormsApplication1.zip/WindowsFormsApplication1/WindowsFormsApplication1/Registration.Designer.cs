﻿namespace WindowsFormsApplication1
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Back = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Email = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.TextBox();
            this.ConfPass = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.UM = new System.Windows.Forms.TextBox();
            this.LM = new System.Windows.Forms.TextBox();
            this.MI = new System.Windows.Forms.TextBox();
            this.FB = new System.Windows.Forms.TextBox();
            this.Registerr = new System.Windows.Forms.Button();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.RadioButton2 = new System.Windows.Forms.RadioButton();
            this.RadioButton1 = new System.Windows.Forms.RadioButton();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.BackColor = System.Drawing.Color.Transparent;
            this.Label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.ForeColor = System.Drawing.Color.Red;
            this.Label13.Location = new System.Drawing.Point(132, 369);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(207, 18);
            this.Label13.TabIndex = 77;
            this.Label13.Text = "E-mail already been used";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.BackColor = System.Drawing.Color.Transparent;
            this.Label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.ForeColor = System.Drawing.Color.Red;
            this.Label12.Location = new System.Drawing.Point(166, 229);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(216, 18);
            this.Label12.TabIndex = 76;
            this.Label12.Text = "Username has been taken";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.BackColor = System.Drawing.Color.Transparent;
            this.Label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.Red;
            this.Label11.Location = new System.Drawing.Point(418, 308);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(213, 18);
            this.Label11.TabIndex = 75;
            this.Label11.Text = "Password does not Match";
            // 
            // Back
            // 
            this.Back.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back.Location = new System.Drawing.Point(456, 492);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(81, 35);
            this.Back.TabIndex = 74;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Clear
            // 
            this.Clear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.Location = new System.Drawing.Point(543, 492);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 35);
            this.Clear.TabIndex = 73;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Email
            // 
            this.Email.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(66, 395);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(179, 26);
            this.Email.TabIndex = 72;
            // 
            // Contact
            // 
            this.Contact.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contact.Location = new System.Drawing.Point(68, 465);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(179, 26);
            this.Contact.TabIndex = 71;
            // 
            // ConfPass
            // 
            this.ConfPass.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfPass.Location = new System.Drawing.Point(257, 337);
            this.ConfPass.Name = "ConfPass";
            this.ConfPass.Size = new System.Drawing.Size(179, 26);
            this.ConfPass.TabIndex = 70;
            // 
            // Password
            // 
            this.Password.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.Location = new System.Drawing.Point(68, 337);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(179, 26);
            this.Password.TabIndex = 69;
            // 
            // UM
            // 
            this.UM.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UM.Location = new System.Drawing.Point(68, 263);
            this.UM.Name = "UM";
            this.UM.Size = new System.Drawing.Size(179, 26);
            this.UM.TabIndex = 68;
            // 
            // LM
            // 
            this.LM.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LM.Location = new System.Drawing.Point(393, 117);
            this.LM.Name = "LM";
            this.LM.Size = new System.Drawing.Size(179, 26);
            this.LM.TabIndex = 67;
            // 
            // MI
            // 
            this.MI.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MI.Location = new System.Drawing.Point(257, 117);
            this.MI.Name = "MI";
            this.MI.Size = new System.Drawing.Size(64, 26);
            this.MI.TabIndex = 66;
            // 
            // FB
            // 
            this.FB.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FB.Location = new System.Drawing.Point(68, 117);
            this.FB.Name = "FB";
            this.FB.Size = new System.Drawing.Size(179, 26);
            this.FB.TabIndex = 65;
            // 
            // Registerr
            // 
            this.Registerr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registerr.Location = new System.Drawing.Point(624, 492);
            this.Registerr.Name = "Registerr";
            this.Registerr.Size = new System.Drawing.Size(97, 35);
            this.Registerr.TabIndex = 64;
            this.Registerr.Text = "Register";
            this.Registerr.UseVisualStyleBackColor = true;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(65, 438);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(144, 18);
            this.Label10.TabIndex = 63;
            this.Label10.Text = "Contact Number:";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(65, 369);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(61, 18);
            this.Label9.TabIndex = 62;
            this.Label9.Text = "E-mail:";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Transparent;
            this.Label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(254, 308);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(158, 18);
            this.Label8.TabIndex = 61;
            this.Label8.Text = "Confirm Password:";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(63, 308);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(92, 18);
            this.Label7.TabIndex = 60;
            this.Label7.Text = "Password:";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(65, 229);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(95, 18);
            this.Label6.TabIndex = 59;
            this.Label6.Text = "Username:";
            // 
            // RadioButton2
            // 
            this.RadioButton2.AutoSize = true;
            this.RadioButton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton2.Location = new System.Drawing.Point(154, 191);
            this.RadioButton2.Name = "RadioButton2";
            this.RadioButton2.Size = new System.Drawing.Size(84, 22);
            this.RadioButton2.TabIndex = 58;
            this.RadioButton2.TabStop = true;
            this.RadioButton2.Text = "Female";
            this.RadioButton2.UseVisualStyleBackColor = true;
            // 
            // RadioButton1
            // 
            this.RadioButton1.AutoSize = true;
            this.RadioButton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadioButton1.Location = new System.Drawing.Point(68, 191);
            this.RadioButton1.Name = "RadioButton1";
            this.RadioButton1.Size = new System.Drawing.Size(63, 22);
            this.RadioButton1.TabIndex = 57;
            this.RadioButton1.TabStop = true;
            this.RadioButton1.Text = "Male";
            this.RadioButton1.UseVisualStyleBackColor = true;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.Transparent;
            this.Label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(390, 80);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(98, 18);
            this.Label5.TabIndex = 56;
            this.Label5.Text = "Last Name:";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(254, 80);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(111, 18);
            this.Label4.TabIndex = 55;
            this.Label4.Text = "Middle Initial:";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(63, 161);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(73, 18);
            this.Label3.TabIndex = 54;
            this.Label3.Text = "Gender:";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(65, 80);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(99, 18);
            this.Label2.TabIndex = 53;
            this.Label2.Text = "First Name:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(29, 20);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(224, 40);
            this.Label1.TabIndex = 52;
            this.Label1.Text = "Registration";
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(733, 539);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.ConfPass);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.UM);
            this.Controls.Add(this.LM);
            this.Controls.Add(this.MI);
            this.Controls.Add(this.FB);
            this.Controls.Add(this.Registerr);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.RadioButton2);
            this.Controls.Add(this.RadioButton1);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.DoubleBuffered = true;
            this.Name = "Registration";
            this.Text = "Registration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Button Back;
        internal System.Windows.Forms.Button Clear;
        internal System.Windows.Forms.TextBox Email;
        internal System.Windows.Forms.TextBox Contact;
        internal System.Windows.Forms.TextBox ConfPass;
        internal System.Windows.Forms.TextBox Password;
        internal System.Windows.Forms.TextBox UM;
        internal System.Windows.Forms.TextBox LM;
        internal System.Windows.Forms.TextBox MI;
        internal System.Windows.Forms.TextBox FB;
        internal System.Windows.Forms.Button Registerr;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.RadioButton RadioButton2;
        internal System.Windows.Forms.RadioButton RadioButton1;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
    }
}